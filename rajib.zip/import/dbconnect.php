<?php
$connect = mysql_connect("localhost","root","niitianrajib") or die("not connect server");
mysql_select_db("travel_bureau",$connect) or die("not connect database");
?>
