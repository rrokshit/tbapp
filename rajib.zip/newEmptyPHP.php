<?php
//single
$_manish = array('0','1','2','3','4');

//double
$_manish = array();
$_manish [0][1] = 'Manish';
$_manish [0][2] = 'Kumar';
$_manish [1][1] = 'Avinash';
$_manish [1][2] = 'Kumar';

//Multi

$_manish = array(); 

$_manish['name']['rajib']='kumar';
$_manish['name']['rajib']['kumar']='kumar1';
$_manish['name']['rajib']['kumar']['kumar1'] ='kumar2';
?>
